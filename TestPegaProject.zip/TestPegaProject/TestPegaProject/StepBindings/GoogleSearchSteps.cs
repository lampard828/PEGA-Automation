﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;

namespace TestPegaProject.StepBindings
{
    class GoogleSearchSteps
    {
        IWebDriver driver;

        [Given (@"That I am on the PEGA web page")]
        public void GivenThatIamOnThePEGAWebPage()
        {
            string browser = Environment.GetEnvironmentVariable("browser", EnvironmentVariableTarget.Process);
            switch (browser)
            {
                case "chrome":
                    driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                    break;
                case "firefox":
                    driver = new FirefoxDriver();
                    break;
                default:
                    driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                    break;
            }
            driver.Url = "https://pegafpssqa.pg.com/prweb/PRAuth/app/FPSS/4kns6fUzYbcj04ZkaCAaiA*/!STANDARD";
        }
        [When(@"I search for Test Cases")]
        public void WhenISearchForTestCases()
        {
            driver.FindElement(By.Name("q")).SendKeys("PEGA" + Keys.Enter);
            Thread.Sleep(2000);
        }
        [Then(@"I expect to see Test Cases on the first page")]
        public void ThenIExpectToSeeTestCasesOnTheFirstPage()
        {
            string strResults = driver.FindElement(By.Id("rso")).Text;
            Assert.True(strResults.Contains("PEGA"));
            Thread.Sleep(2000);
            driver.Quit();
        }

        [Then(@"I expect to see Test Cases on the first page or not")]
        public void ThenIExpectToSeeTestCasesOnTheFirstPageOrNot()
        {
            Thread.Sleep(2000);
            var isDisplayed = driver.FindElement(By.XPath("//h2[text()='Casesss']")).Displayed;
            Assert.That(isDisplayed, Is.True);

            var filePath = $"{TestContext.CurrentContext.TestDirectory}\\{TestContext.CurrentContext.Test.MethodName}.jpg";
            ((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(filePath); //va a tomar un ss si falla la carga de la pag

            TestContext.AddTestAttachment(filePath);
        }

    }
}
